@echo off
setlocal
cd /d "%~dp0"

set PYTHON_EXE=D:\Python38\python.exe
set GIT_EXE=D:\PortableGit\bin\git.exe

if not exist "%PYTHON_EXE%" (
    echo [ERROR] Python not found at %PYTHON_EXE%
    pause
    exit /b 1
)

if not exist "%GIT_EXE%" (
    echo [ERROR] git.exe not found at %GIT_EXE%
    pause
    exit /b 1
)

set PATH=D:\PortableGit\bin;%PATH%
set PYTHONUNBUFFERED=1

echo Running GitHub sync...
echo.

"%PYTHON_EXE%" sync_repos.py

set EXITCODE=%ERRORLEVEL%
echo.
if %EXITCODE%==0 (
    echo Sync completed successfully.
) else if %EXITCODE%==2 (
    echo Sync finished with some failures. Re-run to retry them.
) else if %EXITCODE%==3 (
    echo Sync interrupted.
) else (
    echo Sync failed ^(exit code %EXITCODE%^).
)

echo.
pause >nul
endlocal