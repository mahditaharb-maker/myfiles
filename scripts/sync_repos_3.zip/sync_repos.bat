@echo off
setlocal
cd /d "%~dp0"

set PYTHON_EXE=D:\Python38\python.exe
set GIT_EXE=D:\PortableGit\bin\git.exe

REM ---- GitHub token (needed for private repos, auto-create, and push) ----
REM Set it here, or set it in your user environment before running this file.
REM Do NOT commit this file with a real token in it.
if "%GITHUB_TOKEN%"=="" (
    set GITHUB_TOKEN=ghp_REPLACE_ME
)

if not exist "%PYTHON_EXE%" (
    echo [ERROR] Python not found at %PYTHON_EXE%
    pause
    exit /b 1
)

if not exist "%GIT_EXE%" (
    echo [ERROR] git.exe not found at %GIT_EXE%
    pause
    exit /b 1
)

set PATH=D:\PortableGit\bin;%PATH%
set PYTHONUNBUFFERED=1
set PYTHONIOENCODING=utf-8

echo Running GitHub sync...
echo.

"%PYTHON_EXE%" sync_repo.py
set EXITCODE=%ERRORLEVEL%

echo.
if %EXITCODE%==0 (
    echo Sync completed successfully.
) else if %EXITCODE%==2 (
    echo Sync finished with some failures. Re-run to retry them.
) else if %EXITCODE%==3 (
    echo Sync interrupted.
) else (
    echo Sync failed ^(exit code %EXITCODE%^).
)

echo.
pause
endlocal
exit /b %EXITCODE%