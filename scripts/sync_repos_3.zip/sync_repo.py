"""
GitHub Repository Sync - bidirectional with auto-recovery and auto-create.

  - Clones new GitHub repos, pulls updates for existing ones
  - Commits and pushes local changes (reliable push with retry + rebase)
  - Auto-creates GitHub repos for local-only folders
  - Repairs detached-HEAD repos
  - Skips empty repos without error spam

Two-way behavior:
  - GitHub -> local : fetch --all --prune --tags, pull with ff-only/rebase/merge fallback
  - local -> GitHub : auto-commit dirty working tree, push with retry-on-reject
  - diverged        : rebase local commits on top of remote, then push
  - conflicts       : abort rebase, report clearly, leave repo untouched

Token:
  Read from the GITHUB_TOKEN environment variable. Set it in sync_repos.bat
  (set GITHUB_TOKEN=...) or once with: setx GITHUB_TOKEN "ghp_..."
  Do NOT hardcode the token in this file.
"""

import json
import os
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

# ============ CONFIGURATION ============
GITHUB_USER = "mahditaharb-maker"
# Token is read from the environment. Set it in sync_repos.bat, not here.
GITHUB_TOKEN = os.environ.get("GITHUB_TOKEN", "")
GIT_USER_NAME = "mahditaharb-maker"
GIT_USER_EMAIL = "mahditaharb@gmail.com"
GIT_EXE = r"D:\PortableGit\bin\git.exe"
BASE_DIR = Path(r"E:\archives\GitHubSync\repos")

PUSH_LOCAL_CHANGES = True          # auto-commit dirty working tree
AUTO_CREATE_NEW_REPOS = True
NEW_REPOS_PRIVATE = False
MAX_FILE_MB = 500                  # None = unlimited
COMMIT_PREFIX = "Auto-sync"

GIT_RETRIES = 3
GIT_RETRY_DELAY = 6
API_RETRIES = 3
API_RETRY_DELAY = 6
API_TIMEOUT = 30

PUSH_RETRIES = 2                   # total push attempts before giving up
RECOVERY_BRANCHES = ["main", "master"]
# =======================================


def safe_print(text):
    try:
        print(text)
    except Exception:
        try:
            print(text.encode("ascii", "replace").decode("ascii"))
        except Exception:
            pass


def token_status():
    """Return (usable, message). Never prints the token itself."""
    if not GITHUB_TOKEN:
        return False, "MISSING (push & auto-create will fail)"
    if GITHUB_TOKEN == "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":
        return False, "PLACEHOLDER (edit sync_repos.bat or use setx)"
    if GITHUB_TOKEN.startswith("github_pat_"):
        # Fine-grained tokens are ~93 chars.
        if len(GITHUB_TOKEN) < 60:
            return False, ("SUSPICIOUS (fine-grained token should be ~90 chars, "
                           "got %d)" % len(GITHUB_TOKEN))
        return True, "set (%d chars, fine-grained)" % len(GITHUB_TOKEN)
    if GITHUB_TOKEN.startswith("ghp_"):
        # Classic tokens are exactly 40 chars.
        if len(GITHUB_TOKEN) != 40:
            return False, ("SUSPICIOUS (classic token should be 40 chars, "
                           "got %d) - token is probably truncated"
                           % len(GITHUB_TOKEN))
        return True, "set (40 chars, classic)"
    return True, ("set (%d chars, unknown format, starts with '%s')"
                  % (len(GITHUB_TOKEN), GITHUB_TOKEN[:4]))


# ---------- GitHub API ----------

def api_request(url, method="GET", payload=None):
    data = None
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")

    last_error = None
    for attempt in range(1, API_RETRIES + 1):
        try:
            req = urllib.request.Request(url, data=data, method=method)
            req.add_header("Accept", "application/vnd.github+json")
            req.add_header("User-Agent", "python-sync-script")
            if data is not None:
                req.add_header("Content-Type", "application/json")
            if GITHUB_TOKEN:
                req.add_header("Authorization", "token " + GITHUB_TOKEN)
            with urllib.request.urlopen(req, timeout=API_TIMEOUT) as response:
                body = response.read().decode("utf-8")
                if not body:
                    return {}
                return json.loads(body)
        except urllib.error.HTTPError as e:
            if 400 <= e.code < 500 and e.code != 429:
                raise
            last_error = e
            if attempt < API_RETRIES:
                safe_print("    (API attempt %d/%d failed, retrying in %ds...)"
                           % (attempt, API_RETRIES, API_RETRY_DELAY))
                time.sleep(API_RETRY_DELAY)
        except Exception as e:
            last_error = e
            if attempt < API_RETRIES:
                safe_print("    (API attempt %d/%d failed, retrying in %ds...)"
                           % (attempt, API_RETRIES, API_RETRY_DELAY))
                time.sleep(API_RETRY_DELAY)
    raise last_error


def get_all_repos():
    """Return (repos, ok). ok=False if the API failed partway through."""
    repos = []
    page = 1
    ok = True
    while True:
        url = ("https://api.github.com/user/repos" if GITHUB_TOKEN
               else "https://api.github.com/users/%s/repos" % GITHUB_USER)
        url += "?per_page=100&page=%d&sort=updated&affiliation=owner,collaborator" % page
        try:
            data = api_request(url)
        except Exception as e:
            safe_print("[ERROR] Failed to fetch page %d: %s" % (page, e))
            ok = False
            break
        if not data:
            break
        for r in data:
            repos.append((r["name"], r["clone_url"]))
        if len(data) < 100:
            break
        page += 1
    return repos, ok


def create_github_repo(name):
    """Return (created_or_exists, already_existed)."""
    url = "https://api.github.com/user/repos"
    payload = {
        "name": name,
        "private": NEW_REPOS_PRIVATE,
        "auto_init": False,
        "description": "Auto-created by sync script",
    }
    try:
        api_request(url, method="POST", payload=payload)
        return True, False
    except urllib.error.HTTPError as e:
        if e.code == 422:
            # 422 is ambiguous: already exists, invalid name, reserved, taken.
            # Verify by trying to GET it.
            check_url = "https://api.github.com/repos/%s/%s" % (GITHUB_USER, name)
            try:
                api_request(check_url)
                return True, True
            except Exception:
                safe_print("    [ERROR] name '%s' rejected by GitHub (422)" % name)
                return False, False
        safe_print("    [ERROR] create repo failed: HTTP %d %s"
                   % (e.code, e.reason))
        return False, False
    except Exception as e:
        safe_print("    [ERROR] create repo failed: %s" % e)
        return False, False


def repos_from_local_folders():
    results = []
    if not BASE_DIR.exists():
        return results
    for entry in BASE_DIR.iterdir():
        if entry.is_dir() and (entry / ".git").exists():
            results.append((entry.name, None))
    return results


# ---------- Git helpers ----------

def run_git(args, cwd=None, retries=GIT_RETRIES, delay=GIT_RETRY_DELAY, quiet=False):
    for attempt in range(1, retries + 1):
        try:
            stdout = subprocess.DEVNULL if quiet else None
            stderr = subprocess.DEVNULL if quiet else None
            result = subprocess.call(
                [GIT_EXE] + args, cwd=cwd,
                stdout=stdout, stderr=stderr,
            )
            if result == 0:
                return True
            if attempt < retries:
                if not quiet:
                    safe_print("      attempt %d failed, retrying in %ds..."
                               % (attempt, delay))
                time.sleep(delay)
        except Exception as e:
            if not quiet:
                safe_print("[ERROR] git %s failed: %s" % (" ".join(args), e))
            if attempt < retries:
                time.sleep(delay)
    return False


def git_output(args, cwd=None):
    try:
        result = subprocess.run(
            [GIT_EXE] + args, cwd=cwd,
            capture_output=True, text=True,
        )
        if result.returncode != 0:
            return None
        return result.stdout.strip()
    except Exception:
        return None


def clean_remote_url(url):
    """Strip any embedded credentials from a URL."""
    if not url:
        return url
    if "@" in url and url.startswith("https://"):
        scheme, rest = url.split("://", 1)
        if "@" in rest:
            _, host_and_path = rest.split("@", 1)
            return "%s://%s" % (scheme, host_and_path)
    return url


def get_remote_url(repo_path):
    return git_output(["remote", "get-url", "origin"], cwd=str(repo_path))


def set_remote_url(repo_path, url):
    url = clean_remote_url(url)
    if get_remote_url(repo_path):
        run_git(["remote", "set-url", "origin", url],
                cwd=str(repo_path), quiet=True)
    else:
        run_git(["remote", "add", "origin", url],
                cwd=str(repo_path), quiet=True)


def configure_git_identity(repo_path):
    run_git(["config", "user.name", GIT_USER_NAME], cwd=str(repo_path), quiet=True)
    run_git(["config", "user.email", GIT_USER_EMAIL], cwd=str(repo_path), quiet=True)


def is_valid_repo(repo_path):
    if not (repo_path / ".git").exists():
        return False
    return git_output(["rev-parse", "--git-dir"], cwd=str(repo_path)) is not None


def get_current_branch(repo_path):
    branch = git_output(["rev-parse", "--abbrev-ref", "HEAD"], cwd=str(repo_path))
    return branch if branch and branch != "HEAD" else None


def has_upstream(repo_path):
    return git_output(
        ["rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}"],
        cwd=str(repo_path),
    ) is not None


def count_commits_ahead(repo_path):
    out = git_output(["rev-list", "--count", "@{u}..HEAD"], cwd=str(repo_path))
    try:
        return int(out) if out else 0
    except ValueError:
        return 0


def count_commits_behind(repo_path):
    out = git_output(["rev-list", "--count", "HEAD..@{u}"], cwd=str(repo_path))
    try:
        return int(out) if out else 0
    except ValueError:
        return 0


def get_status_short(repo_path):
    out = git_output(["status", "--porcelain"], cwd=str(repo_path))
    if out is None:
        return []
    return [l for l in out.split("\n") if l.strip()]


def is_mid_operation(repo_path):
    """True if a merge/rebase/cherry-pick is in progress."""
    git_dir = repo_path / ".git"
    if not git_dir.exists():
        return False
    markers = [
        git_dir / "MERGE_HEAD",
        git_dir / "REBASE_HEAD",
        git_dir / "CHERRY_PICK_HEAD",
        git_dir / "rebase-merge",
        git_dir / "rebase-apply",
    ]
    return any(m.exists() for m in markers)


def find_oversized_files(repo_path, max_mb=MAX_FILE_MB):
    if max_mb is None:
        return []
    max_bytes = max_mb * 1024 * 1024
    oversized = []
    out = git_output(["ls-files", "-co", "--exclude-standard"], cwd=str(repo_path))
    if out is None:
        return oversized
    for rel in out.split("\n"):
        rel = rel.strip()
        if not rel:
            continue
        full = repo_path / rel
        try:
            if full.is_file():
                size = full.stat().st_size
                if size > max_bytes:
                    oversized.append((rel, size / (1024 * 1024)))
        except OSError:
            pass
    return oversized


def branch_has_commits(repo_path, branch):
    out = git_output(["rev-list", "-n", "1", branch], cwd=str(repo_path))
    return bool(out)


def remote_branch_exists(repo_path, branch):
    out = git_output(
        ["rev-parse", "--verify", "refs/remotes/origin/%s" % branch],
        cwd=str(repo_path),
    )
    return bool(out)


def fetch_all(repo_path):
    return run_git(["fetch", "--all", "--prune", "--tags"],
                   cwd=str(repo_path), quiet=True)


# ---------- Detached HEAD recovery ----------

def list_remote_branches(repo_path):
    out = git_output(
        ["for-each-ref", "--format=%(refname:short)", "refs/remotes/origin"],
        cwd=str(repo_path),
    )
    if not out:
        return []
    branches = []
    for line in out.split("\n"):
        line = line.strip()
        if not line or line.endswith("/HEAD"):
            continue
        if line.startswith("origin/"):
            branches.append(line[len("origin/"):])
    return branches


def recover_detached_head(repo_path):
    fetch_all(repo_path)
    remote_branches = list_remote_branches(repo_path)

    for candidate in RECOVERY_BRANCHES:
        local_exists = git_output(
            ["rev-parse", "--verify", candidate], cwd=str(repo_path)
        ) is not None
        remote_exists = candidate in remote_branches
        if not (local_exists or remote_exists):
            continue
        if run_git(["checkout", candidate], cwd=str(repo_path), quiet=True):
            safe_print("    [recover] checked out '%s'" % candidate)
            return candidate

    if remote_branches:
        candidate = remote_branches[0]
        if run_git(["checkout", "-B", candidate, "origin/%s" % candidate],
                   cwd=str(repo_path), quiet=True):
            safe_print("    [recover] created local branch '%s' from origin"
                       % candidate)
            return candidate

    if not remote_branches:
        if run_git(["checkout", "-b", "main"], cwd=str(repo_path), quiet=True):
            safe_print("    [recover] created empty branch 'main'")
            return "main"

    safe_print("    [recover] FAILED - no usable branch found")
    return None


# ---------- Pull with fallback ----------

def pull_with_fallback(repo_path, behind):
    """Try ff-only, then rebase, then merge. Return True on success."""
    safe_print("    pulling %d commit(s)" % behind)

    if run_git(["pull", "--ff-only"], cwd=str(repo_path), quiet=True):
        return True

    safe_print("    ff-only failed, trying rebase")
    if run_git(["pull", "--rebase"], cwd=str(repo_path), quiet=True):
        return True

    # Rebase may have left us mid-rebase; abort cleanly before trying merge.
    if is_mid_operation(repo_path):
        run_git(["rebase", "--abort"], cwd=str(repo_path), quiet=True)

    safe_print("    rebase failed, trying merge")
    if run_git(["pull", "--no-rebase"], cwd=str(repo_path), quiet=True):
        return True

    if is_mid_operation(repo_path):
        # Abort so next run starts from a clean state.
        run_git(["merge", "--abort"], cwd=str(repo_path), quiet=True)

    safe_print("    [CONFLICT] could not reconcile. Fix manually:")
    safe_print("      cd %s" % repo_path)
    safe_print("      git pull")
    return False


# ---------- Reliable push ----------

def push_with_retry(repo_path, branch):
    """Push, and if rejected, refetch + rebase, then retry once."""
    for attempt in range(1, PUSH_RETRIES + 1):
        if run_git(["push", "-u", "origin", branch], cwd=str(repo_path)):
            return True

        if attempt == PUSH_RETRIES:
            break

        safe_print("    push rejected, refetching and retrying...")
        fetch_all(repo_path)

        if not has_upstream(repo_path):
            # Newly published branch — retry push directly.
            continue

        behind = count_commits_behind(repo_path)
        if behind > 0:
            if not run_git(["pull", "--rebase"], cwd=str(repo_path), quiet=True):
                run_git(["rebase", "--abort"], cwd=str(repo_path), quiet=True)
                safe_print("    [CONFLICT] rebase failed on push-retry:")
                safe_print("      cd %s" % repo_path)
                safe_print("      git pull --rebase")
                return False

    safe_print("    [ERROR] push rejected after %d attempts" % PUSH_RETRIES)
    return False


# ---------- Sync one existing repo ----------

def sync_repo(name, clone_url):
    repo_path = BASE_DIR / name

    if not clone_url:
        existing_url = get_remote_url(repo_path)
        if not existing_url:
            safe_print("  [skip]   %s - no remote URL found" % name)
            return
        clone_url = existing_url

    clone_url_clean = clean_remote_url(clone_url)
    auth_url = clone_url

    if not is_valid_repo(repo_path):
        if repo_path.exists():
            safe_print("  [clean]  removing broken folder for %s" % name)
            try:
                shutil.rmtree(str(repo_path))
            except Exception as e:
                safe_print("    [WARN] could not remove: %s" % e)
                return
        safe_print("  [clone]  %s" % name)
        if run_git(["clone", auth_url, str(repo_path)]):
            configure_git_identity(repo_path)
            set_remote_url(repo_path, clone_url_clean)
            safe_print("    cloned")
        return

    configure_git_identity(repo_path)
    set_remote_url(repo_path, clone_url_clean)

    if is_mid_operation(repo_path):
        safe_print("  [skip]   %s - merge/rebase in progress, resolve manually"
                   % name)
        return

    branch = get_current_branch(repo_path)

    if not branch:
        fetch_all(repo_path)
        if not list_remote_branches(repo_path) and not git_output(
            ["rev-list", "-n", "1", "--all"], cwd=str(repo_path)
        ):
            safe_print("  [skip]   %s - empty repo" % name)
            return

        safe_print("  [sync]   %s (detached HEAD - attempting recovery)" % name)
        branch = recover_detached_head(repo_path)
        if not branch:
            safe_print("  [skip]   %s - recovery failed" % name)
            return

    safe_print("  [sync]   %s (branch: %s)" % (name, branch))

    if not fetch_all(repo_path):
        safe_print("    [WARN] fetch failed, skipping")
        return

    if not branch_has_commits(repo_path, branch):
        if remote_branch_exists(repo_path, branch):
            safe_print("    local branch empty, syncing from origin/%s" % branch)
            if not run_git(["checkout", "-B", branch, "origin/%s" % branch],
                           cwd=str(repo_path), quiet=True):
                safe_print("    [ERROR] could not reset to origin/%s" % branch)
                return
        else:
            safe_print("    [skip] branch '%s' has no commits yet" % branch)
            return

    # ----- Auto-commit dirty working tree -----
    if PUSH_LOCAL_CHANGES:
        status_lines = get_status_short(repo_path)

        if status_lines:
            oversized = find_oversized_files(repo_path)

            if oversized:
                safe_print("    [BLOCKED] %d file(s) over %d MB:"
                           % (len(oversized), MAX_FILE_MB))
                for path, size in oversized[:5]:
                    safe_print("      %.1f MB  %s" % (size, path))
                safe_print("    Not committing. Add them to .gitignore.")
            else:
                safe_print("    local changes: %d file(s)" % len(status_lines))
                for line in status_lines[:8]:
                    safe_print("      %s" % line)
                if len(status_lines) > 8:
                    safe_print("      ... and %d more" % (len(status_lines) - 8))

                if not run_git(["add", "-A"], cwd=str(repo_path)):
                    safe_print("    [ERROR] git add failed")
                    return
                msg = "%s: %s" % (COMMIT_PREFIX, time.strftime("%Y-%m-%d %H:%M:%S"))
                if run_git(["commit", "-m", msg], cwd=str(repo_path), quiet=True):
                    safe_print("    committed: %s" % msg)
                else:
                    safe_print("    [ERROR] commit failed")
                    return

    if not branch_has_commits(repo_path, branch):
        safe_print("    [skip] branch '%s' has no commits" % branch)
        return

    # ----- Push / pull reconciliation -----
    if not has_upstream(repo_path):
        safe_print("    setting upstream for '%s'" % branch)
        if push_with_retry(repo_path, branch):
            safe_print("    pushed (new upstream)")
        else:
            safe_print("    [ERROR] could not set upstream")
        return

    ahead = count_commits_ahead(repo_path)
    behind = count_commits_behind(repo_path)

    if ahead == 0 and behind == 0:
        safe_print("    up to date")
        return

    if ahead > 0 and behind == 0:
        if push_with_retry(repo_path, branch):
            safe_print("    pushed %d commit(s)" % ahead)
        else:
            safe_print("    [ERROR] push failed")
        return

    if ahead == 0 and behind > 0:
        pull_with_fallback(repo_path, behind)
        return

    # Diverged: rebase local on top of remote, then push.
    safe_print("    diverged: %d ahead / %d behind - rebasing" % (ahead, behind))
    if not run_git(["pull", "--rebase"], cwd=str(repo_path), quiet=True):
        run_git(["rebase", "--abort"], cwd=str(repo_path), quiet=True)
        safe_print("    [CONFLICT] rebase failed. Resolve manually:")
        safe_print("      cd %s" % repo_path)
        safe_print("      git pull --rebase")
        return

    if push_with_retry(repo_path, branch):
        safe_print("    pushed %d commit(s)" % ahead)
    else:
        safe_print("    [ERROR] push failed after rebase")


# ---------- Sync local-only folders ----------

def sync_local_only_folder(folder_path, github_names):
    name = folder_path.name

    if name.startswith(".") or name.startswith("-"):
        return False
    if name in github_names:
        return False

    safe_print("  [new]    %s (local-only, not on GitHub)" % name)

    if not (folder_path / ".git").exists():
        safe_print("    initializing git repo")
        if not run_git(["init"], cwd=str(folder_path), quiet=True):
            safe_print("    [ERROR] git init failed")
            return False

    configure_git_identity(folder_path)
    run_git(["branch", "-M", "main"], cwd=str(folder_path), quiet=True)

    oversized = find_oversized_files(folder_path)
    if oversized:
        safe_print("    [BLOCKED] %d file(s) over %d MB:"
                   % (len(oversized), MAX_FILE_MB))
        for path, size in oversized[:5]:
            safe_print("      %.1f MB  %s" % (size, path))
        safe_print("    Skipping this folder.")
        return False

    safe_print("    creating GitHub repo '%s'..." % name)
    ok, already_existed = create_github_repo(name)
    if not ok:
        safe_print("    [ERROR] could not create GitHub repo")
        return False
    if already_existed:
        safe_print("    repo already exists on GitHub, using it")

    remote_url = "https://github.com/%s/%s.git" % (GITHUB_USER, name)
    set_remote_url(folder_path, remote_url)

    if not run_git(["add", "-A"], cwd=str(folder_path)):
        safe_print("    [ERROR] git add failed")
        return False

    staged = git_output(["diff", "--cached", "--name-only"],
                        cwd=str(folder_path))
    if staged:
        msg = "%s: initial import %s" % (
            COMMIT_PREFIX, time.strftime("%Y-%m-%d %H:%M:%S")
        )
        if not run_git(["commit", "-m", msg], cwd=str(folder_path), quiet=True):
            safe_print("    [ERROR] commit failed")
            return False
        safe_print("    committed: %s" % msg)
    else:
        safe_print("    nothing to commit (folder is empty)")

    if not branch_has_commits(folder_path, "main"):
        safe_print("    [skip] no commits to push")
        return False

    safe_print("    pushing to GitHub...")
    if push_with_retry(folder_path, "main"):
        safe_print("    pushed successfully")
        return True

    safe_print("    [ERROR] push failed")
    return False


def sync_all_local_only(github_names):
    if not BASE_DIR.exists():
        return 0
    created = 0
    for entry in sorted(BASE_DIR.iterdir()):
        if not entry.is_dir():
            continue
        if sync_local_only_folder(entry, github_names):
            created += 1
    return created


# ---------- Main ----------

def main():
    safe_print("=" * 60)
    safe_print(" GitHub Repository Sync (bidirectional + auto-create)")
    safe_print("=" * 60)
    safe_print("Using git:      %s" % GIT_EXE)
    safe_print("Push local:     %s" % ("ON" if PUSH_LOCAL_CHANGES else "OFF"))
    safe_print("Auto-create:    %s" % ("ON" if AUTO_CREATE_NEW_REPOS else "OFF"))
    size_label = "unlimited" if MAX_FILE_MB is None else ("%d MB" % MAX_FILE_MB)
    safe_print("Max file size:  %s" % size_label)

    tok_ok, tok_msg = token_status()
    safe_print("Token:          %s" % tok_msg)
    if not tok_ok:
        safe_print("")
        safe_print("  !!! The token looks wrong. The API will return 401 and")
        safe_print("  !!! push will fail. Fix it before relying on this run.")
    safe_print("")

    if not Path(GIT_EXE).exists():
        safe_print("[FATAL] git.exe not found at %s" % GIT_EXE)
        return 1

    if not BASE_DIR.exists():
        BASE_DIR.mkdir(parents=True)
        safe_print("Created %s" % BASE_DIR)

    safe_print("Fetching repository list for '%s'..." % GITHUB_USER)
    try:
        repos, api_ok = get_all_repos()
    except Exception as e:
        safe_print("[FATAL] %s" % e)
        return 1

    if not repos:
        safe_print("")
        safe_print("[FALLBACK] Using local folder scan instead of API.")
        repos = repos_from_local_folders()
        if not repos:
            safe_print("[FATAL] No local repos found either.")
            return 1

    safe_print("Found %d repositories.\n" % len(repos))

    github_names = set()
    succeeded = 0
    failed = []

    for name, url in repos:
        github_names.add(name)
        try:
            sync_repo(name, url)
            succeeded += 1
        except KeyboardInterrupt:
            safe_print("\n[ABORT] interrupted by user.")
            return 3
        except Exception as e:
            safe_print("  [FAIL]   %s -- %s" % (name, e))
            failed.append(name)

    new_repos_created = 0
    if api_ok and AUTO_CREATE_NEW_REPOS:
        safe_print("")
        safe_print("Scanning for local-only folders...")
        try:
            new_repos_created = sync_all_local_only(github_names)
        except KeyboardInterrupt:
            safe_print("\n[ABORT] interrupted by user.")
            return 3

    total = len(repos) + new_repos_created
    total_succeeded = succeeded + new_repos_created

    safe_print("\n" + "=" * 60)
    safe_print(" Sync complete. %d/%d repositories processed."
               % (total_succeeded, total))
    if new_repos_created:
        safe_print(" New GitHub repos created: %d" % new_repos_created)
    if failed:
        safe_print(" Failed: %s" % ", ".join(failed))
        safe_print(" Re-run the script to retry only the failed ones.")
    safe_print(" Location: %s" % BASE_DIR)
    safe_print("=" * 60)
    return 0 if not failed else 2


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        safe_print("\n[ABORT] cancelled.")
        sys.exit(130)