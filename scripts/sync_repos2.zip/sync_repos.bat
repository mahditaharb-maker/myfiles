@echo off
setlocal
cd /d "%~dp0"

REM ============================================
REM  GitHub Repository Sync
REM  Uses the paths you specified
REM ============================================

set PYTHON_EXE=E:\archives\Github\tools\Python38\python.exe
set GIT_EXE=D:\PortableGit\bin\git.exe

if not exist "%PYTHON_EXE%" (
    echo [ERROR] Python not found at %PYTHON_EXE%
    pause
    exit /b 1
)

if not exist "%GIT_EXE%" (
    echo [ERROR] git.exe not found at %GIT_EXE%
    pause
    exit /b 1
)

echo Using Python: %PYTHON_EXE%
echo Using git:    %GIT_EXE%
echo.

REM Make this git first in PATH
for %%G in ("%GIT_EXE%") do set GIT_BIN=%%~dpG
set PATH=%GIT_BIN%;%PATH%
set PYTHONUNBUFFERED=1

echo Running GitHub sync...
echo.

"%PYTHON_EXE%" "%~dp0sync_repos.py"

set EXITCODE=%ERRORLEVEL%
echo.
if %EXITCODE%==0 (
    echo Sync completed successfully.
) else if %EXITCODE%==2 (
    echo Sync finished with some failures. Re-run to retry them.
) else if %EXITCODE%==3 (
    echo Sync interrupted.
) else (
    echo Sync failed ^(exit code %EXITCODE%^).
)

echo.
pause >nul
endlocal