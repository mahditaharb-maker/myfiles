"""
GitHub Repository Sync - bidirectional with auto-recovery and auto-create.

  - Clones new GitHub repos, pulls updates for existing ones
  - Commits and pushes local changes
  - Auto-creates GitHub repos for local-only folders
  - Repairs detached-HEAD repos
  - Skips empty repos without error spam
  - Path-independent: works wherever the script is placed
"""

import json
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

# ============ CONFIGURATION ============
GITHUB_USER = "mahditaharb-maker"

# >>> Paste your PERSONAL ACCESS TOKEN between the quotes below. <<<
# Generate one at: https://github.com/settings/tokens
# Required scopes: repo, workflow
GITHUB_TOKEN = "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"

GIT_USER_NAME = "mahditaharb-maker"
GIT_USER_EMAIL = "mahditaharb@gmail.com"

# Path-independent: BASE_DIR is the "repos" folder next to this script.
SCRIPT_DIR = Path(__file__).resolve().parent
BASE_DIR = SCRIPT_DIR / "repos"

# Candidate git.exe locations (first existing one wins)
GIT_EXE_CANDIDATES = [
    r"D:\PortableGit\bin\git.exe",
]

PUSH_LOCAL_CHANGES = True
AUTO_CREATE_NEW_REPOS = True
NEW_REPOS_PRIVATE = False
MAX_FILE_MB = 500
COMMIT_PREFIX = "Auto-sync"

GIT_RETRIES = 3
GIT_RETRY_DELAY = 6
API_RETRIES = 3
API_RETRY_DELAY = 6
API_TIMEOUT = 30

RECOVERY_BRANCHES = ["main", "master"]
# =======================================


def find_git_exe():
    for candidate in GIT_EXE_CANDIDATES:
        if Path(candidate).exists():
            return candidate
    return "git"


GIT_EXE = find_git_exe()


def safe_print(text):
    try:
        print(text)
    except Exception:
        try:
            print(text.encode("ascii", "replace").decode("ascii"))
        except Exception:
            pass


def token_is_placeholder():
    t = (GITHUB_TOKEN or "").strip()
    return (not t) or t == "PASTE_YOUR_TOKEN_HERE" or not t.startswith("ghp_")


# ---------- GitHub API ----------

def api_request(url, method="GET", payload=None):
    data = None
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")

    last_error = None
    for attempt in range(1, API_RETRIES + 1):
        try:
            req = urllib.request.Request(url, data=data, method=method)
            req.add_header("Accept", "application/vnd.github+json")
            req.add_header("User-Agent", "python-sync-script")
            if data is not None:
                req.add_header("Content-Type", "application/json")
            if GITHUB_TOKEN and not token_is_placeholder():
                req.add_header("Authorization", "token " + GITHUB_TOKEN)
            with urllib.request.urlopen(req, timeout=API_TIMEOUT) as response:
                body = response.read().decode("utf-8")
                if not body:
                    return {}
                return json.loads(body)
        except urllib.error.HTTPError as e:
            if 400 <= e.code < 500 and e.code != 429:
                raise
            last_error = e
            if attempt < API_RETRIES:
                safe_print("    (API attempt %d/%d failed, retrying in %ds...)"
                           % (attempt, API_RETRIES, API_RETRY_DELAY))
                time.sleep(API_RETRY_DELAY)
        except Exception as e:
            last_error = e
            if attempt < API_RETRIES:
                safe_print("    (API attempt %d/%d failed, retrying in %ds...)"
                           % (attempt, API_RETRIES, API_RETRY_DELAY))
                time.sleep(API_RETRY_DELAY)
    raise last_error


def get_all_repos():
    repos = []
    page = 1
    while True:
        url = ("https://api.github.com/user/repos" if GITHUB_TOKEN else
               "https://api.github.com/users/%s/repos" % GITHUB_USER)
        url += "?per_page=100&page=%d&sort=updated&affiliation=owner,collaborator" % page
        try:
            data = api_request(url)
        except Exception as e:
            safe_print("[ERROR] Failed to fetch page %d: %s" % (page, e))
            break
        if not data:
            break
        for r in data:
            repos.append((r["name"], r["clone_url"]))
        if len(data) < 100:
            break
        page += 1
    return repos


def create_github_repo(name):
    url = "https://api.github.com/user/repos"
    payload = {
        "name": name,
        "private": NEW_REPOS_PRIVATE,
        "auto_init": False,
        "description": "Auto-created by sync script",
    }
    try:
        api_request(url, method="POST", payload=payload)
        return True
    except urllib.error.HTTPError as e:
        if e.code == 422:
            return True
        safe_print("    [ERROR] create repo failed: HTTP %d %s"
                   % (e.code, e.reason))
        return False
    except Exception as e:
        safe_print("    [ERROR] create repo failed: %s" % e)
        return False


def repos_from_local_folders():
    results = []
    if not BASE_DIR.exists():
        return results
    for entry in BASE_DIR.iterdir():
        if entry.is_dir() and (entry / ".git").exists():
            results.append((entry.name, None))
    return results


# ---------- Git helpers ----------

def run_git(args, cwd=None, retries=GIT_RETRIES, delay=GIT_RETRY_DELAY, quiet=False):
    for attempt in range(1, retries + 1):
        try:
            stdout = subprocess.DEVNULL if quiet else None
            stderr = subprocess.DEVNULL if quiet else None
            result = subprocess.call(
                [GIT_EXE] + args, cwd=cwd,
                stdout=stdout, stderr=stderr,
            )
            if result == 0:
                return True
            if attempt < retries:
                if not quiet:
                    safe_print("      attempt %d failed, retrying in %ds..."
                               % (attempt, delay))
                time.sleep(delay)
        except Exception as e:
            if not quiet:
                safe_print("[ERROR] git %s failed: %s" % (" ".join(args), e))
            if attempt < retries:
                time.sleep(delay)
    return False


def git_output(args, cwd=None):
    try:
        result = subprocess.run(
            [GIT_EXE] + args, cwd=cwd,
            capture_output=True, text=True,
        )
        if result.returncode != 0:
            return None
        return result.stdout.strip()
    except Exception:
        return None


def inject_token(url):
    if not GITHUB_TOKEN or not url or token_is_placeholder():
        return url
    if url.startswith("https://github.com/"):
        return url.replace(
            "https://github.com/",
            "https://%s:%s@github.com/" % (GITHUB_USER, GITHUB_TOKEN),
        )
    return url


def get_remote_url(repo_path):
    return git_output(["remote", "get-url", "origin"], cwd=str(repo_path))


def set_remote_url(repo_path, url):
    if get_remote_url(repo_path):
        run_git(["remote", "set-url", "origin", url],
                cwd=str(repo_path), quiet=True)
    else:
        run_git(["remote", "add", "origin", url],
                cwd=str(repo_path), quiet=True)


def configure_git_identity(repo_path):
    run_git(["config", "user.name", GIT_USER_NAME], cwd=str(repo_path), quiet=True)
    run_git(["config", "user.email", GIT_USER_EMAIL], cwd=str(repo_path), quiet=True)


def is_valid_repo(repo_path):
    if not (repo_path / ".git").exists():
        return False
    return git_output(["rev-parse", "--git-dir"], cwd=str(repo_path)) is not None


def get_current_branch(repo_path):
    branch = git_output(["rev-parse", "--abbrev-ref", "HEAD"], cwd=str(repo_path))
    return branch if branch and branch != "HEAD" else None


def has_upstream(repo_path):
    return git_output(
        ["rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}"],
        cwd=str(repo_path),
    ) is not None


def count_commits_ahead(repo_path):
    out = git_output(["rev-list", "--count", "@{u}..HEAD"], cwd=str(repo_path))
    try:
        return int(out) if out else 0
    except ValueError:
        return 0


def count_commits_behind(repo_path):
    out = git_output(["rev-list", "--count", "HEAD..@{u}"], cwd=str(repo_path))
    try:
        return int(out) if out else 0
    except ValueError:
        return 0


def get_status_short(repo_path):
    out = git_output(["status", "--porcelain"], cwd=str(repo_path))
    if out is None:
        return []
    return [l for l in out.split("\n") if l.strip()]


def find_oversized_files(repo_path, max_mb=MAX_FILE_MB):
    if max_mb is None:
        return []
    max_bytes = max_mb * 1024 * 1024
    oversized = []
    out = git_output(["ls-files", "-co", "--exclude-standard"], cwd=str(repo_path))
    if out is None:
        return oversized
    for rel in out.split("\n"):
        rel = rel.strip()
        if not rel:
            continue
        full = repo_path / rel
        try:
            if full.is_file():
                size = full.stat().st_size
                if size > max_bytes:
                    oversized.append((rel, size / (1024 * 1024)))
        except OSError:
            pass
    return oversized


def branch_has_commits(repo_path, branch):
    out = git_output(["rev-list", "-n", "1", branch], cwd=str(repo_path))
    return bool(out)


# ---------- Detached HEAD recovery ----------

def list_remote_branches(repo_path):
    out = git_output(
        ["for-each-ref", "--format=%(refname:short)", "refs/remotes/origin"],
        cwd=str(repo_path),
    )
    if not out:
        return []
    branches = []
    for line in out.split("\n"):
        line = line.strip()
        if not line or line.endswith("/HEAD"):
            continue
        if line.startswith("origin/"):
            branches.append(line[len("origin/"):])
    return branches


def recover_detached_head(repo_path):
    run_git(["fetch", "--all"], cwd=str(repo_path), quiet=True)
    remote_branches = list_remote_branches(repo_path)

    for candidate in RECOVERY_BRANCHES:
        local_exists = git_output(
            ["rev-parse", "--verify", candidate], cwd=str(repo_path)
        ) is not None
        remote_exists = candidate in remote_branches
        if not (local_exists or remote_exists):
            continue
        if run_git(["checkout", candidate], cwd=str(repo_path), quiet=True):
            safe_print("    [recover] checked out '%s'" % candidate)
            return candidate

    if remote_branches:
        candidate = remote_branches[0]
        if run_git(["checkout", "-B", candidate, "origin/%s" % candidate],
                   cwd=str(repo_path), quiet=True):
            safe_print("    [recover] created local branch '%s' from origin"
                       % candidate)
            return candidate

    if not remote_branches:
        if run_git(["checkout", "-b", "main"], cwd=str(repo_path), quiet=True):
            safe_print("    [recover] created empty branch 'main'")
            return "main"

    safe_print("    [recover] FAILED - no usable branch found")
    return None


# ---------- Sync one existing repo ----------

def sync_repo(name, clone_url):
    repo_path = BASE_DIR / name

    if not clone_url:
        existing_url = get_remote_url(repo_path)
        if not existing_url:
            safe_print("  [skip]   %s - no remote URL found" % name)
            return
        clone_url = existing_url
    auth_url = inject_token(clone_url)

    if not is_valid_repo(repo_path):
        if repo_path.exists():
            safe_print("  [clean]  removing broken folder for %s" % name)
            try:
                shutil.rmtree(str(repo_path))
            except Exception as e:
                safe_print("    [WARN] could not remove: %s" % e)
                return
        safe_print("  [clone]  %s" % name)
        if run_git(["clone", auth_url, str(repo_path)]):
            configure_git_identity(repo_path)
            safe_print("    cloned")
        return

    configure_git_identity(repo_path)

    branch = get_current_branch(repo_path)

    if not branch:
        run_git(["fetch", "--all"], cwd=str(repo_path), quiet=True)
        if not list_remote_branches(repo_path) and not git_output(
            ["rev-list", "-n", "1", "--all"], cwd=str(repo_path)
        ):
            safe_print("  [skip]   %s - empty repo" % name)
            return

        safe_print("  [sync]   %s (detached HEAD - attempting recovery)" % name)
        branch = recover_detached_head(repo_path)
        if not branch:
            safe_print("  [skip]   %s - recovery failed" % name)
            return

    safe_print("  [sync]   %s (branch: %s)" % (name, branch))

    if not run_git(["fetch"], cwd=str(repo_path), quiet=True):
        safe_print("    [WARN] fetch failed, skipping")
        return

    status_lines = get_status_short(repo_path)

    if status_lines and PUSH_LOCAL_CHANGES:
        oversized = find_oversized_files(repo_path)

        if oversized:
            safe_print("    [BLOCKED] %d file(s) over %d MB:"
                       % (len(oversized), MAX_FILE_MB))
            for path, size in oversized[:5]:
                safe_print("      %.1f MB  %s" % (size, path))
            safe_print("    Not committing. Add them to .gitignore.")
        else:
            safe_print("    local changes: %d file(s)" % len(status_lines))
            for line in status_lines[:8]:
                safe_print("      %s" % line)
            if len(status_lines) > 8:
                safe_print("      ... and %d more" % (len(status_lines) - 8))

            if not run_git(["add", "-A"], cwd=str(repo_path)):
                safe_print("    [ERROR] git add failed")
                return
            msg = "%s: %s" % (COMMIT_PREFIX, time.strftime("%Y-%m-%d %H:%M:%S"))
            if run_git(["commit", "-m", msg], cwd=str(repo_path), quiet=True):
                safe_print("    committed: %s" % msg)
            else:
                safe_print("    [ERROR] commit failed")
                return

    if not branch_has_commits(repo_path, branch):
        safe_print("    [skip] branch '%s' has no commits (empty repo)"
                   % branch)
        return

    if not has_upstream(repo_path):
        safe_print("    setting upstream for '%s'" % branch)
        if run_git(["push", "-u", "origin", branch], cwd=str(repo_path)):
            safe_print("    pushed (new upstream)")
        else:
            safe_print("    [ERROR] could not set upstream")
        return

    ahead = count_commits_ahead(repo_path)
    behind = count_commits_behind(repo_path)

    if ahead > 0:
        if behind > 0:
            safe_print("    diverged: %d ahead / %d behind - rebasing"
                       % (ahead, behind))
            if not run_git(["pull", "--rebase"], cwd=str(repo_path)):
                safe_print("    [CONFLICT] rebase failed. Resolve manually:")
                safe_print("      cd %s" % repo_path)
                safe_print("      git pull --rebase")
                run_git(["rebase", "--abort"], cwd=str(repo_path), quiet=True)
                return
        if run_git(["push"], cwd=str(repo_path)):
            safe_print("    pushed %d commit(s)" % ahead)
        else:
            safe_print("    [ERROR] push failed")
    elif behind > 0:
        safe_print("    pulling %d commit(s)" % behind)
        run_git(["pull", "--ff-only"], cwd=str(repo_path))
    else:
        safe_print("    up to date")


# ---------- Sync local-only folders ----------

def sync_local_only_folder(folder_path, github_names):
    name = folder_path.name

    if name.startswith(".") or name.startswith("-"):
        return False
    if name in github_names:
        return False

    safe_print("  [new]    %s (local-only, not on GitHub)" % name)

    if not (folder_path / ".git").exists():
        safe_print("    initializing git repo")
        if not run_git(["init"], cwd=str(folder_path), quiet=True):
            safe_print("    [ERROR] git init failed")
            return False

    configure_git_identity(folder_path)
    run_git(["branch", "-M", "main"], cwd=str(folder_path), quiet=True)

    oversized = find_oversized_files(folder_path)
    if oversized:
        safe_print("    [BLOCKED] %d file(s) over %d MB:"
                   % (len(oversized), MAX_FILE_MB))
        for path, size in oversized[:5]:
            safe_print("      %.1f MB  %s" % (size, path))
        safe_print("    Skipping this folder.")
        return False

    safe_print("    creating GitHub repo '%s'..." % name)
    if not create_github_repo(name):
        safe_print("    [ERROR] could not create GitHub repo")
        return False

    remote_url = "https://%s:%s@github.com/%s/%s.git" % (
        GITHUB_USER, GITHUB_TOKEN, GITHUB_USER, name
    )
    set_remote_url(folder_path, remote_url)

    if not run_git(["add", "-A"], cwd=str(folder_path)):
        safe_print("    [ERROR] git add failed")
        return False

    staged = git_output(["diff", "--cached", "--name-only"],
                        cwd=str(folder_path))
    if staged:
        msg = "%s: initial import %s" % (
            COMMIT_PREFIX, time.strftime("%Y-%m-%d %H:%M:%S")
        )
        if not run_git(["commit", "-m", msg], cwd=str(folder_path), quiet=True):
            safe_print("    [ERROR] commit failed")
            return False
        safe_print("    committed: %s" % msg)
    else:
        safe_print("    nothing to commit (folder is empty)")

    if not branch_has_commits(folder_path, "main"):
        safe_print("    [skip] no commits to push")
        return False

    safe_print("    pushing to GitHub...")
    if run_git(["push", "-u", "origin", "main"], cwd=str(folder_path)):
        safe_print("    pushed successfully")
        return True

    safe_print("    [ERROR] push failed")
    return False


def sync_all_local_only(github_names):
    if not BASE_DIR.exists():
        return 0
    created = 0
    for entry in sorted(BASE_DIR.iterdir()):
        if not entry.is_dir():
            continue
        if sync_local_only_folder(entry, github_names):
            created += 1
    return created


# ---------- Main ----------

def main():
    safe_print("=" * 60)
    safe_print(" GitHub Repository Sync (bidirectional + auto-create)")
    safe_print("=" * 60)
    safe_print("Script dir:     %s" % SCRIPT_DIR)
    safe_print("Repos dir:      %s" % BASE_DIR)
    safe_print("Using git:      %s" % GIT_EXE)
    safe_print("Push local:     %s" % ("ON" if PUSH_LOCAL_CHANGES else "OFF"))
    safe_print("Auto-create:    %s" % ("ON" if AUTO_CREATE_NEW_REPOS else "OFF"))
    size_label = "unlimited" if MAX_FILE_MB is None else ("%d MB" % MAX_FILE_MB)
    safe_print("Max file size:  %s" % size_label)

    if token_is_placeholder():
        safe_print("Token:          MISSING (edit GITHUB_TOKEN in this file)")
    else:
        safe_print("Token:          loaded")

    safe_print("")

    if not BASE_DIR.exists():
        BASE_DIR.mkdir(parents=True)
        safe_print("Created %s" % BASE_DIR)

    safe_print("Fetching repository list for '%s'..." % GITHUB_USER)
    try:
        repos = get_all_repos()
    except Exception as e:
        safe_print("[FATAL] %s" % e)
        return 1

    api_ok = bool(repos)

    if not repos:
        safe_print("")
        safe_print("[FALLBACK] Using local folder scan instead of API.")
        repos = repos_from_local_folders()
        if not repos:
            safe_print("[FATAL] No local repos found either.")
            return 1

    safe_print("Found %d repositories.\n" % len(repos))

    github_names = set()
    succeeded = 0
    failed = []

    for name, url in repos:
        github_names.add(name)
        try:
            sync_repo(name, url)
            succeeded += 1
        except KeyboardInterrupt:
            safe_print("\n[ABORT] interrupted by user.")
            return 3
        except Exception as e:
            safe_print("  [FAIL]   %s -- %s" % (name, e))
            failed.append(name)

    new_repos_created = 0
    if api_ok and AUTO_CREATE_NEW_REPOS:
        safe_print("")
        safe_print("Scanning for local-only folders...")
        try:
            new_repos_created = sync_all_local_only(github_names)
        except KeyboardInterrupt:
            safe_print("\n[ABORT] interrupted by user.")
            return 3

    total = len(repos) + new_repos_created
    total_succeeded = succeeded + new_repos_created

    safe_print("\n" + "=" * 60)
    safe_print(" Sync complete. %d/%d repositories processed."
               % (total_succeeded, total))
    if new_repos_created:
        safe_print(" New GitHub repos created: %d" % new_repos_created)
    if failed:
        safe_print(" Failed: %s" % ", ".join(failed))
        safe_print(" Re-run the script to retry only the failed ones.")
    safe_print(" Location: %s" % BASE_DIR)
    safe_print("=" * 60)
    return 0 if not failed else 2


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        safe_print("\n[ABORT] cancelled.")
        sys.exit(130)