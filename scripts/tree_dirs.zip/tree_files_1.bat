@echo off
setlocal enabledelayedexpansion

:: ============================================
:: Directory Tree Generator - Windows 7 Compatible
:: ============================================

:: ---- Args ----
if "%~1"=="" (
    set "TARGET_DIR=%CD%"
) else (
    set "TARGET_DIR=%~1"
)
set "OUTPUT_FILE=%~2"
if "%OUTPUT_FILE%"=="" set "OUTPUT_FILE=directory_tree.txt"

:: Strip trailing backslash unless drive root
if "%TARGET_DIR:~-1%"=="\" (
    if not "%TARGET_DIR:~1,1%"==":" set "TARGET_DIR=%TARGET_DIR:~0,-1%"
)
if not exist "%TARGET_DIR%\" (
    echo ERROR: Directory "%TARGET_DIR%" does not exist.
    pause & exit /b 1
)
for %%A in ("%TARGET_DIR%") do set "TARGET_DIR=%%~fA"
if "%TARGET_DIR:~-1%"=="\" (
    set "BASE=%TARGET_DIR:~0,-1%"
) else (
    set "BASE=%TARGET_DIR%"
)

:: ---- Counters ----
set /a DIR_COUNT=0
set /a FILE_COUNT=0

:: ---- Windows 7 safe startup ----
title Generating Directory Tree...
echo.
echo ============================================
echo  DIRECTORY TREE GENERATOR - WORKING...
echo ============================================
echo.
echo  Root   : %TARGET_DIR%
echo  Output : %OUTPUT_FILE%
echo.
echo  Scanning directories...
echo.

:: ---- Write output header ----
> "%OUTPUT_FILE%" echo ============================================
>> "%OUTPUT_FILE%" echo  DIRECTORY TREE REPORT
>> "%OUTPUT_FILE%" echo  Root: %TARGET_DIR%
>> "%OUTPUT_FILE%" echo  Generated: %DATE% %TIME%
>> "%OUTPUT_FILE%" echo ============================================
>> "%OUTPUT_FILE%" echo.

:: ---- Run the walk ----
call :WalkDir "%BASE%" ""

:: ---- Final summary ----
echo.
echo ============================================
echo  COMPLETED
echo ============================================
echo.
echo  Directories : %DIR_COUNT%
echo  Files       : %FILE_COUNT%
echo  Output      : %OUTPUT_FILE%
echo.
pause
exit /b 0

:: ============================================
:: RECURSIVE WALKER
:: ============================================
:WalkDir
setlocal enabledelayedexpansion
set "DIR=%~1"
set "INDENT=%~2"

set /a DIR_COUNT+=1

:: Progress line (overwrites same line using backspace trick)
set "PROGRESS=[DIR %DIR_COUNT%] %DIR%"
if defined PROGRESS set "PROGRESS=!PROGRESS:~0,78!"
<nul set /p "=!PROGRESS!     "
echo.

:: Directory header
for %%A in ("%DIR%") do set "DNAME=%%~nxA"
if "%DNAME%"=="" set "DNAME=%DIR%"
>> "%OUTPUT_FILE%" echo !INDENT![DIR] !DNAME!\

:: Files
for /f "delims=" %%F in ('dir /b /a-d /on "%DIR%\*" 2^>nul') do (
    set /a FILE_COUNT+=1
    set "FNAME=%%F"
    set "EXT=%%~xF"
    if "!EXT!"=="" (
        >> "%OUTPUT_FILE%" echo !INDENT!  ^|-- !FNAME! [no extension]
    ) else (
        >> "%OUTPUT_FILE%" echo !INDENT!  ^|-- !FNAME! !EXT!
    )
)

:: Subdirectories
for /f "delims=" %%D in ('dir /b /ad /on "%DIR%\*" 2^>nul') do (
    call :WalkDir "%DIR%\%%D" "!INDENT!  "
)

endlocal
exit /b 0