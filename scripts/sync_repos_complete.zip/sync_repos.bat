@echo off
setlocal
cd /d "%~dp0"

set PYTHON_EXE=D:\Python38\python.exe
set GIT_EXE=D:\PortableGit\bin\git.exe

rem ---- Real sync mode (no dry-run prompt). Set to 1 to preview first. ----
set DRY_RUN_FIRST=0

if not exist "%PYTHON_EXE%" (
    echo [ERROR] Python not found at %PYTHON_EXE%
    pause
    exit /b 1
)

if not exist "%GIT_EXE%" (
    echo [ERROR] git.exe not found at %GIT_EXE%
    pause
    exit /b 1
)

set PATH=D:\PortableGit\bin;%PATH%
set PYTHONUNBUFFERED=1

rem ---- Token lives in sync_repos.py (GITHUB_TOKEN constant) ----

echo ============================================================
echo  GitHub Repository Sync
echo ============================================================
echo.

if "%DRY_RUN_FIRST%"=="1" (
    echo [STEP 1/2] Dry run - no changes will be made...
    echo.
    "%PYTHON_EXE%" sync_repos.py --dry-run
    echo.
    echo ------------------------------------------------------------
    echo Dry run finished. Review the output above.
    echo.
    choice /c YN /n /m "Proceed with the real sync now? [Y/N] "
    if errorlevel 2 (
        echo.
        echo Cancelled. Nothing was changed.
        echo.
        pause >nul
        endlocal
        exit /b 0
    )
    echo.
    echo [STEP 2/2] Running real sync...
    echo.
)

"%PYTHON_EXE%" sync_repos.py

set EXITCODE=%ERRORLEVEL%
echo.
if %EXITCODE%==0 (
    echo Sync completed successfully.
) else if %EXITCODE%==2 (
    echo Sync finished with some failures. Re-run to retry them.
) else if %EXITCODE%==3 (
    echo Sync interrupted.
) else (
    echo Sync failed ^(exit code %EXITCODE%^).
)

echo.
pause >nul
endlocal