@echo off
setlocal
cd /d "%~dp0"

set PYTHON_EXE=D:\Python38\python.exe
set GIT_EXE=D:\PortableGit\bin\git.exe

rem ---- Real sync mode (no dry-run prompt). Set to 1 to preview first. ----
set DRY_RUN_FIRST=0

if not exist "%PYTHON_EXE%" (
    echo [ERROR] Python not found at %PYTHON_EXE%
    pause
    exit /b 1
)

if not exist "%GIT_EXE%" (
    echo [ERROR] git.exe not found at %GIT_EXE%
    pause
    exit /b 1
)

set PATH=D:\PortableGit\bin;%PATH%
set PYTHONUNBUFFERED=1

rem ---- Never let git hang on a credential prompt. ----
set GIT_TERMINAL_PROMPT=0

echo ============================================================
echo  GitHub Repository Sync
echo ============================================================
echo.
echo  Paste your GitHub token below and press Enter.
echo  (Token is not echoed to screen.)
echo.
echo  Required scopes:  repo, delete_repo
echo  Generate at:      https://github.com/settings/tokens/new
echo.

set "GITHUB_TOKEN="
for /f "usebackq delims=" %%p in (`powershell -NoProfile -Command "$s = Read-Host -AsSecureString 'Token'; $b = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($s); [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($b)"`) do set "GITHUB_TOKEN=%%p"

if "%GITHUB_TOKEN%"=="" (
    echo.
    echo [ERROR] No token entered. Aborting.
    pause
    exit /b 1
)

echo.
echo ============================================================
echo.

if "%DRY_RUN_FIRST%"=="1" (
    echo [STEP 1/2] Dry run - no changes will be made...
    echo.
    "%PYTHON_EXE%" sync_repos.py --dry-run
    echo.
    echo ------------------------------------------------------------
    echo Dry run finished. Review the output above.
    echo.
    choice /c YN /n /m "Proceed with the real sync now? [Y/N] "
    if errorlevel 2 (
        echo.
        echo Cancelled. Nothing was changed.
        echo.
        pause >nul
        endlocal
        exit /b 0
    )
    echo.
    echo [STEP 2/2] Running real sync...
    echo.
)

"%PYTHON_EXE%" sync_repos.py

set EXITCODE=%ERRORLEVEL%
echo.
if %EXITCODE%==0 (
    echo Sync completed successfully.
) else if %EXITCODE%==2 (
    echo Sync finished with some failures. Re-run to retry them.
) else if %EXITCODE%==3 (
    echo Sync interrupted.
) else (
    echo Sync failed ^(exit code %EXITCODE%^).
)

echo.
pause >nul
endlocal