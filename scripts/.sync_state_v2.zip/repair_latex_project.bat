@echo off
setlocal
cd /d "%~dp0"
set PYTHON_EXE=D:\Python38\python.exe
set GIT_TERMINAL_PROMPT=0
"%PYTHON_EXE%" repair_latex_project.py
pause
endlocal