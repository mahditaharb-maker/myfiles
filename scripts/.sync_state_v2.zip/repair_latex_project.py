"""
One-shot repair for the latex-project repo, which is stuck mid-rebase
with a binary PDF conflict and some stray 'cd'/'git' files.
"""
import os
import subprocess
import sys
from pathlib import Path

GIT  = r"D:\PortableGit\bin\git.exe"
REPO = Path(r"E:\archives\GitHubSync\repos\latex-project")
PDF  = "document/The-Fundamental-Theorem-of-Calculus-in-Mathlib-26A42.pdf"

if not (REPO / ".git").exists():
    print("[FATAL] not a git repo:", REPO)
    sys.exit(1)

os.chdir(str(REPO))

def git(*args):
    r = subprocess.run([GIT] + list(args), cwd=str(REPO),
                       capture_output=True, text=True)
    return r.returncode, (r.stdout or "").strip(), (r.stderr or "").strip()

def show(title, *args):
    print("--- %s ---" % title)
    rc, out, err = git(*args)
    if out: print(out)
    if err: print("[stderr] " + err)
    print()

print("=" * 60)
print(" BEFORE")
print("=" * 60)
show("status",       "status", "--short", "--branch")
show("HEAD",         "rev-parse", "HEAD")
show("describe",     "describe", "--tags", "--always")
show("reflog",       "reflog", "-n", "8")

print("=" * 60)
print(" STEP 1: abort the stuck rebase")
print("=" * 60)
rc, out, err = git("rebase", "--abort")
print("rebase --abort -> rc=%d" % rc)
if out: print(out)
if err: print(err)
if rc != 0:
    print("trying: reset --merge")
    rc2, out2, err2 = git("reset", "--merge")
    print("reset --merge -> rc=%d" % rc2)
    if err2: print(err2)
print()
show("status after abort", "status", "--short", "--branch")

print("=" * 60)
print(" STEP 2: inspect stray 'cd' and 'git' items")
print("=" * 60)
for name in ("cd", "git"):
    p = REPO / name
    if not p.exists():
        print("[absent] %s" % name)
    elif p.is_dir():
        children = list(p.iterdir())
        print("[DIR ] %s  (%d entries)" % (name, len(children)))
        for c in children[:10]:
            print("         " + c.name)
    else:
        size = p.stat().st_size
        print("[FILE] %s  size=%d bytes" % (name, size))
        if size and size < 4096:
            try:
                print("         content: %r" % p.read_text(errors="replace")[:200])
            except Exception:
                pass
print()

input("Press Enter to continue the repair, or Ctrl-C to abort... ")
print()

print("=" * 60)
print(" STEP 3: rewrite main on top of origin/main")
print("=" * 60)
rc, out, err = git("reset", "--soft", "origin/main")
print("reset --soft origin/main -> rc=%d" % rc)
if err: print(err)
if rc != 0:
    print("[FATAL] reset --soft failed. Stopping here; nothing was lost.")
    sys.exit(1)
print()
show("staged for commit", "status", "--short")

# Remove stray cd/git IF they're trivially removable (empty file / empty dir).
for name in ("cd", "git"):
    p = REPO / name
    if not p.exists():
        continue
    if p.is_dir():
        try:
            p.rmdir()
            print("removed empty dir:  %s" % name)
        except OSError:
            print("kept non-empty dir: %s" % name)
    else:
        if p.stat().st_size == 0:
            p.unlink()
            print("removed empty file: %s" % name)
        else:
            print("kept non-empty file: %s" % name)

# Restore the remote's freshly-compiled PDF over our stale local copy,
# because the CI on the server is what regenerates it.
print()
print("Restoring remote's compiled PDF (from origin/main)...")
rc, out, err = git("checkout", "HEAD", "--", PDF)
print("checkout HEAD -- PDF -> rc=%d" % rc)
if err: print(err)

print()
git("add", "-A")
show("final staged set", "diff", "--cached", "--stat")

input("Press Enter to commit and push, or Ctrl-C to abort... ")

rc, out, err = git("commit", "-m",
                   "Auto-sync: repair after rebase conflict (keep CI PDF)")
if rc != 0:
    print("[WARN] commit returned rc=%d" % rc)
    if out: print(out)
    if err: print(err)

rc, out, err = git("push", "origin", "main")
print("push -> rc=%d" % rc)
if err: print(err)

print()
print("=" * 60)
print(" FINAL STATE")
print("=" * 60)
show("status", "status", "--short", "--branch")
show("log",    "log", "--oneline", "-n", "6")

print("Done. Now re-run sync_repos.bat.")
print("latex-project should report:  (branch: main)  /  up to date")